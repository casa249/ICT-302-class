+++
author = "syui"
comments = false
date = "2017-01-01"
draft = false
image = ""
menu = ""
share = false
slug = "test"
title= "sample"
+++

[Hugo](https://gohugo.io/documentation/) is the world's fastest static website engine. It's written in Go (aka Golang) and developed by bep, `spf13` and friends.

> Below you will find some of the most common and helpful pages from our documentation.

https://gohugo.io/documentation/

